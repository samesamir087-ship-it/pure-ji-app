import 'package:flutter/material.dart';

void main() {
  runApp(const PureJiApp());
}

class PureJiApp extends StatelessWidget {
  const PureJiApp({super.key});

  @override
  Widget build(BuildContext context) {
    const forest = Color(0xFF176B45);
    return MaterialApp(
      title: 'Pure Ji',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: forest),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F8F5),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF7F8F5),
          foregroundColor: Color(0xFF153D2B),
          elevation: 0,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class MilkProduct {
  const MilkProduct({
    required this.name,
    required this.description,
    required this.price,
    required this.unit,
    required this.icon,
  });

  final String name;
  final String description;
  final int price;
  final String unit;
  final IconData icon;
}

const products = <MilkProduct>[
  MilkProduct(
    name: 'Fresh Cow Milk',
    description: 'Daily milk delivery',
    price: 95,
    unit: '500 ml',
    icon: Icons.water_drop_outlined,
  ),
  MilkProduct(
    name: 'Family Milk Pack',
    description: 'For your everyday needs',
    price: 180,
    unit: '1 litre',
    icon: Icons.local_drink_outlined,
  ),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Map<String, int> quantities = {};
  bool subscriptionSelected = false;

  int get total => products.fold(
        0,
        (sum, product) => sum + (quantities[product.name] ?? 0) * product.price,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.spa_outlined, color: Color(0xFF176B45)),
            SizedBox(width: 8),
            Text('Pure Ji', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Account (coming soon)',
            onPressed: () => _message('Customer login will be connected in a later step.'),
            icon: const Icon(Icons.person_outline),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFFE5F2E8),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Good milk. Simple mornings.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF153D2B))),
                SizedBox(height: 8),
                Text('Fresh milk delivered to your doorstep.', style: TextStyle(fontSize: 15, color: Color(0xFF365C48))),
                SizedBox(height: 16),
                Row(children: [
                  Icon(Icons.delivery_dining, color: Color(0xFF176B45)),
                  SizedBox(width: 8),
                  Text('Home delivery in selected areas', style: TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text('Choose your milk', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          for (final product in products) _productCard(product),
          const SizedBox(height: 8),
          Card(
            elevation: 0,
            child: SwitchListTile(
              title: const Text('Daily subscription', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Subscription setup will be connected later'),
              value: subscriptionSelected,
              onChanged: (value) => setState(() => subscriptionSelected = value),
              secondary: const Icon(Icons.calendar_month_outlined),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Order total', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                    Text('₹$total', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF176B45))),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: total == 0 ? null : () => _message('Demo only: order placement, address, and payment are not connected yet.'),
                  child: const Text('Continue to order'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Center(child: Text('Pure Ji • Freshness at your doorstep', style: TextStyle(color: Colors.black54))),
        ],
      ),
    );
  }

  Widget _productCard(MilkProduct product) {
    final quantity = quantities[product.name] ?? 0;
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              height: 62,
              width: 62,
              decoration: BoxDecoration(color: const Color(0xFFE5F2E8), borderRadius: BorderRadius.circular(16)),
              child: Icon(product.icon, size: 32, color: const Color(0xFF176B45)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text('${product.unit} • ${product.description}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
                  const SizedBox(height: 6),
                  Text('₹${product.price}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                ],
              ),
            ),
            quantity == 0
                ? OutlinedButton(
                    onPressed: () => setState(() => quantities[product.name] = 1),
                    child: const Text('ADD'),
                  )
                : Row(
                    children: [
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: () => setState(() {
                          if (quantity <= 1) {
                            quantities.remove(product.name);
                          } else {
                            quantities[product.name] = quantity - 1;
                          }
                        }),
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text('$quantity', style: const TextStyle(fontWeight: FontWeight.w800)),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: () => setState(() => quantities[product.name] = quantity + 1),
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  void _message(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

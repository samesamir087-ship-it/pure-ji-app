# Pure Ji — Milk Delivery App

Starter Flutter project for the Pure Ji milk delivery app (Android + iOS).

## Included in this starter
- Flutter customer app UI starter
- Product catalogue and quantity selection
- Cart summary and order request UI (demo only; no real payments or backend yet)
- GitHub Actions workflow to build an Android APK when Flutter source is present

## Important
This is a starter scaffold, not a production-ready commerce app. Before accepting real orders or payments, connect a backend, configure authentication, payment provider, delivery workflows, privacy policy, and required food-business compliance. Real payment verification must happen server-side.

## Build
Install Flutter SDK, then run:
```bash
flutter pub get
flutter run
```

import 'package:flutter_test/flutter_test.dart';
import 'package:pure_ji_app/main.dart';

void main() {
  testWidgets('Pure Ji home screen renders products', (tester) async {
    await tester.pumpWidget(const PureJiApp());
    expect(find.text('Pure Ji'), findsOneWidget);
    expect(find.text('Fresh Cow Milk'), findsOneWidget);
    expect(find.text('Continue to order'), findsOneWidget);
  });
}
